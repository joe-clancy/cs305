package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.validation.constraints.Size;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
@Validated
class ServerController{ 
	// Default message if one is not provided
	private final String defaultMsg = "Joe Clancy";
	
    @RequestMapping("/hash")
    public String returnGreeting(@RequestParam(value = "msg", defaultValue = defaultMsg) @Size(max = 25) String data) throws Exception {
    	return myHash(data);
    }
    
    public String myHash(String data) throws NoSuchAlgorithmException{
    	// Create unique string
    	// String data = "Joe Clancy, 6/22/2024, CS305, 7-1 Project 2";
       
        // Create MessageDigest instance for SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // Generate hash value (checksum)
        byte[] hash = md.digest(data.getBytes());

        // Convert byte array to hex string
        String checksum = bytesToHex(hash);

        // Format and return results
        return "<p>data:"+data+"<p> Cipher Algorithm Used: "+md.getAlgorithm()+"<p> Cheksum value: "+checksum;
    }
    
    private static String bytesToHex(byte[] bytes) {
    	// Convert byte array to hex string
        StringBuilder sb = new StringBuilder();
        
        // Iterate through bytes
        for (byte b : bytes) {
        	// Convert byte to hex and append
            sb.append(String.format("%02x", b));
        }
        // Return converted hex string
        return sb.toString();
    }
}

